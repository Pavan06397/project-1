<?php
$conn=mysqli_connect("localhost","root","","payment");
if(!$conn){
    die("Connection failed: " . mysqli_connect_error());
}

$name=$_POST['name'];
$email=$_POST['email'];
$address=$_POST['address'];
$city=$_POST['city'];
$state=$_POST['state'];
$pincode=$_POST['pincode'];
$card= isset($_POST['card']) ? $_POST['card'] : '';
$cod= isset($_POST['cod']) ? $_POST['cod'] : '';
$cardName=$_POST['cardName'];
$cardNumber=$_POST['cardNumber'];
$expMonth=$_POST['expMonth'];
$expYear=$_POST['expYear'];
$cvv=$_POST['cvv'];

$data = "INSERT INTO payment1 VALUES ('','$name','$email','$address','$city','$state','$pincode','$card','$cod','$cardName','$cardNumber','$expMonth','$expYear','$cvv')";
$check = mysqli_query($conn,$data);
if($check){
    echo "LOGIN SUCCESSFUL!";
} else{
    echo "LOGIN FAILED!";
}
?>
