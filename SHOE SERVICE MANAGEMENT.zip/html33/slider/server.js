const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(bodyParser.json());

let message = '';

app.post('/send', (req, res) => {
  message = req.body.message;
  console.log('Sender sent:', message);
  res.sendStatus(200);
});

app.get('/receive', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');

  res.write('\n');
  res.write(`data: ${JSON.stringify({ message })}\n\n`);

  console.log('Receiver received:', message);
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
