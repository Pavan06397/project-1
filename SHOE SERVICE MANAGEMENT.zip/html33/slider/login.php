<?php
$conn=mysqli_connect("localhost","root","","pavan");
if($conn){
   // echo "connected";
}
else{
    echo "failed";
}
$username=$_POST['username'];
$password=$_POST['password'];

$data = "INSERT INTO login VALUES('','$username','$password')";
$check = mysqli_query($conn,$data);
if($check){
    echo ".............................................................................LOGIN SUCCESSFULLY!!!!!!!!!!............................................................";
}
else{
    echo "............................................................................RE LOGIN PLASE!!!!!!!!....................................................................";
}
?>