<?php
$conn = mysqli_connect("localhost", "root", "", "test");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$email = $_POST['email'];
$name = $_POST['name'];
$password = $_POST['password'];
$repassword = $_POST['repassword'];

$sql = "INSERT INTO registration3 (email, name, password, repassword) VALUES ('$email', '$name', '$password', '$repassword')";

if (mysqli_query($conn, $sql)) {
    echo ".............................................................................REGISTERED SUCCESSFULLY!!!!!!!!!!............................................................";
} else {
    echo "............................................................................FAILED TO REGISTER....................................................................";
}

mysqli_close($conn);
?>